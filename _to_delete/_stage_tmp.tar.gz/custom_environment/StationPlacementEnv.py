import gymnasium as gym
from gymnasium import spaces
import numpy as np
from stable_baselines3.common.env_checker import check_env
import pickle
import random
from random import choice
import custom_environment.helpers as H
from custom_environment.graph_features import GraphFeatureAugmentor
import sys
import os
import copy
import json

# Add parent directory to path to allow importing power_grid
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
if parent_dir not in sys.path:
    sys.path.append(parent_dir)

from custom_environment.power_grid.csprl_adapter import create_adapter_for_location
from custom_environment.power_grid.feasibility import GridFeasibilityLayer

"""
Custom environment
"""


class FeatureScaler:
    """
    Scale features separately based on realistic ranges.
    All outputs are in [-1, 1] to match Box observation space.
    """

    def __init__(self, location="DongDa", base_dir=None):
        if base_dir is None:
            base_dir = os.path.dirname(os.path.abspath(__file__))

        json_path = os.path.join(base_dir, "data", "Graph", location, "scaling_constants.json")

        # Load from file if exists, otherwise use reasonable defaults
        if os.path.exists(json_path):
            try:
                with open(json_path, "r") as f:
                    data = json.load(f)
                self.lon_min = data.get("x_min", 105.798)
                self.lon_max = data.get("x_max", 105.843)
                self.lat_min = data.get("y_min", 20.997)
                self.lat_max = data.get("y_max", 21.032)
                self.pop_min = data.get("pop_min", 2.646)
                self.pop_max = data.get("pop_max", 425.7)
                self.land_price_max = data.get("land_price_max", 186.2)
                self.demand_max = data.get("demand_max", 0.91)
                self.grid_dist_max = data.get("grid_dist_max", 1.02)
                self.grid_mw_max = data.get("grid_mw_max", 12.8)
                self.street_count_max = data.get("street_count_max", 5.0)
                self.road_length_max = data.get("road_length_max", 363.0)
                self.dist_to_station_max = data.get("dist_to_station_max", 2.0)
                self.capability_max = data.get("capability_max", 1.5)
                self.benefit_max = data.get("benefit_max", 2.0)
                print(f"Loaded scaling constants for {location} successfully.")
            except Exception as e:
                print(f"Error loading scaling JSON: {e}. Using default values.")
                self._set_defaults()
        else:
            print(f"Scaling JSON not found at {json_path}. Using default values.")
            self._set_defaults()

        self.charger_max = float(H.K)
        self.budget_max = float(H.BUDGET)

    def _set_defaults(self):
        self.lon_min, self.lon_max = 105.798, 105.843
        self.lat_min, self.lat_max = 20.997, 21.032
        self.pop_min, self.pop_max = 2.646, 425.7
        self.land_price_max = 186.2
        self.demand_max = 0.91
        self.grid_dist_max = 1.02
        self.grid_mw_max = 12.8
        self.street_count_max = 5.0
        self.road_length_max = 363.0
        self.dist_to_station_max = 2.0
        self.capability_max = 1.5
        self.benefit_max = 2.0

    def scale_lon(self, v):
        return 2 * (np.clip(v, self.lon_min, self.lon_max) - self.lon_min) / (self.lon_max - self.lon_min + 1e-9) - 1

    def scale_lat(self, v):
        return 2 * (np.clip(v, self.lat_min, self.lat_max) - self.lat_min) / (self.lat_max - self.lat_min + 1e-9) - 1

    def scale_pop(self, v):
        return 2 * (np.clip(v, self.pop_min, self.pop_max) - self.pop_min) / (self.pop_max - self.pop_min + 1e-9) - 1

    def scale_demand(self, v):
        return 2 * np.clip(v / (self.demand_max + 1e-9), 0, 1) - 1

    def scale_land_price(self, v):
        return 2 * np.clip(v / (self.land_price_max + 1e-9), 0, 1) - 1

    def scale_private_cs(self, v):
        return 2 * np.clip(v / (1.0 + 1e-9), 0, 1) - 1

    def scale_charger_count(self, v):
        return 2 * (np.clip(v, 0, self.charger_max) / (self.charger_max + 1e-9)) - 1

    def scale_budget(self, v):
        return 2 * (np.clip(v, 0, self.budget_max) / (self.budget_max + 1e-9)) - 1

    def scale_grid_distance(self, v):
        return 2 * np.clip(v / (self.grid_dist_max + 1e-9), 0, 1) - 1

    def scale_grid_mw(self, v):
        return 2 * np.clip(v / (self.grid_mw_max + 1e-9), 0, 1) - 1

    def scale_benefit(self, v):
        return 2 * np.clip(v / (self.benefit_max + 1e-9), 0, 1) - 1

    def scale_capability(self, v):
        return 2 * np.clip(v / (self.capability_max + 1e-9), 0, 1) - 1

    def scale_nearest_station_dist(self, v):
        return 2 * np.clip(v / (self.dist_to_station_max + 1e-9), 0, 1) - 1

    def scale_street_count(self, v):
        return 2 * (np.clip(v, 1.0, self.street_count_max) - 1.0) / (self.street_count_max - 1.0 + 1e-9) - 1

    def scale_road_length(self, v):
        return 2 * np.clip(v / (self.road_length_max + 1e-9), 0, 1) - 1


class Plan:
    def __init__(self, my_node_list, my_node_dict, my_cost_dict, my_plan_file, graph):
        with (open(my_plan_file, "rb")) as f:
            self.plan = pickle.load(f)
        self.plan = [H.s_dictionnary(my_station, my_node_list) for my_station in self.plan]
        my_node_list, _, _ = H.station_seeking(self.plan, my_node_list, my_node_dict, my_cost_dict, graph)
        # update the dictionnary
        self.plan = [H.s_dictionnary(my_station, my_node_list) for my_station in self.plan]
        self.norm_benefit, self.norm_cost, self.norm_charg, self.norm_wait, self.norm_travel, _ = \
            H.existing_score(self.plan, my_node_list)
        # NOTE: shallow copy on purpose -- existing_plan below must hold the *same*
        # node objects as self.plan so the `s[0] not in existing_plan` identity test
        # in _control_action() keeps working while node attrs get mutated in place.
        self.extend_existing_plan = self.plan.copy()
        self.existing_plan = [s[0] for s in self.extend_existing_plan]
        # Because of that aliasing, s[2]["fee"] of these stations keeps changing as
        # the agent adds chargers to them (installment_fee writes in place). Snapshot
        # the baseline installation cost NOW; reading it back after an episode would
        # return the inflated post-episode fees and make "budget used" too small --
        # or negative, if the best plan was captured before those upgrades happened.
        self.basic_cost = sum(s[2]["fee"] for s in self.plan)

    def __repr__(self):
        return "The charging plan is {}".format(self.plan)

    def add_plan(self, my_station):
        self.plan.append(my_station)

    def remove_plan(self, my_station):
        self.plan.remove(my_station)

    def steal_column(self, stolen_station, my_budget):
        """
        steal a charger from the station, give budget back and check which charger type has been stolen
        """
        my_budget += stolen_station[2]["fee"]
        station_index = self.plan.index(stolen_station)
        config_index = None

        # we choose the most expensive charging column
        N_types = len(H.CHARGING_POWER)
        for i in reversed(range(N_types)):
            if stolen_station[1][i] > 0:
                self.plan[station_index][1][i] -= 1
                config_index = i
                break # if found the largest port, move to the next step

        if sum(stolen_station[1]) == 0:
            # this means we remove the entire stations as it only has one charger
            self.remove_plan(stolen_station)
        else:
            # the station remains, we only steal one charging column
            H.installment_fee(stolen_station)
            my_budget -= stolen_station[2]["fee"]
            my_budget -= H.get_relocate_cost(config_index) # add relocate cost
        return my_budget, config_index


class Station:
    def __init__(self):
        self.s_pos = None # station positioon
        self.s_x = None # station config
        self.s_dict = {} # this use to store additional station data (fee, )
        self.station = [self.s_pos, self.s_x, self.s_dict]

    def __repr__(self):
        return "This station is {}".format(self.station)

    def add_position(self, my_node):
        self.station[0] = my_node

    def add_chargers(self, my_config):
        self.station[1] = my_config

    def establish_dictionnary(self, node_list):
        self.station = H.s_dictionnary(self.station, node_list)


class StationPlacement(gym.Env):
    """Custom Environment that follows gym interface"""

    #: Width of the global (non-per-node) part of the observation. Named because
    #: three separate observation_space branches and establish_observation() must
    #: agree on it; a literal repeated four times is how they silently drift apart.
    N_GLOBAL = 5

    def __init__(self, my_graph_file, my_node_file, my_plan_file, location="DongDa",
                 obs_type="mlp", grid_mode="hard", grid_actions=None):
        """
        Args:
            grid_mode: how the 22 kV bus-capacity limit is imposed.
                "off"  -- no grid term in the score at all (grid-blind baseline).
                "soft" -- capacity violations are priced into norm_score as a
                          penalty. This is what the agent cannot actually act on:
                          the node is picked by a grid-blind heuristic, so the
                          only representable way to lower the penalty is to stop
                          building. Kept as the comparison baseline.
                "hard" -- violations are made impossible by filtering the
                          candidate nodes before the heuristic runs
                          (GridFeasibilityLayer). cap_penalty is then identically
                          zero by construction, and the agent's problem becomes
                          choosing well among feasible placements.
            grid_actions: whether to expose the two grid-aware actions (5: build
                where demand and headroom multiply best; 6: relocate a charger off
                the tightest bus). Defaults to True in "hard" mode. Set False to
                isolate the effect of the projection alone; note this changes the
                action-space size, so checkpoints are not interchangeable.
        """
        super(StationPlacement, self).__init__()

        # Per-instance distance/cost caches (must NOT be class attributes: multiple
        # env instances - e.g. different locations, or VecEnv workers - would
        # otherwise share and corrupt each other's cached node<->station distances).
        self.node_dict = {}
        self.cost_dict = {}

        self.obs_type = obs_type
        if grid_mode not in ("off", "soft", "hard"):
            raise ValueError(f"Unknown grid_mode: {grid_mode}. Must be 'off', 'soft' or 'hard'.")
        self.grid_mode = grid_mode
        # "off" drops the grid term from the score; "soft"/"hard" keep it. In "hard"
        # the capacity part is always 0 (nothing can violate), so what survives is
        # the distance term -- a genuine soft cost (connection cost grows with
        # distance to the feeder), which is the only part that *should* be soft.
        self.use_grid_penalty = grid_mode in ("soft", "hard")
        self.use_hard_constraint = grid_mode == "hard"
        # Debug switch: assert the invariant after every step. Off during training
        # (an assert per step is not free); turned on by the verification script.
        self.verify_grid = False
        # Initialize Grid Adapter with Fallback
        try:
            # Adapter automatically finds data in CSPRL/power_grid/data
            self.grid_adapter = create_adapter_for_location(location)
        except Exception as e:
            print(f"Warning: Could not initialize Power Grid Adapter ({ascii(e)}). Grid constraints will be ignored.")
            self.grid_adapter = None

        _graph, self.node_list = H.prepare_graph(my_graph_file, my_node_file)
        self.graph = _graph
        self.node_id_to_idx = {node[0]: idx for idx, node in enumerate(self.node_list)}

        self.node_list = [self._init(my_node) for my_node in self.node_list]

        # Episode horizon. Capped so a district's node count does not decide how many
        # decisions the agent gets: without the cap, 120k training steps buy ~811
        # episodes on DongDa but only ~123 on NamTuLiem, far short of the ~500 needed
        # to converge. Defined once here because establish_observation() normalizes
        # progress by it -- a second literal there would silently drift out of sync
        # and leave the agent blind to how much of the episode is left.
        self.max_steps = min(len(self.node_list) / 2, 350)

        self.plan_file = my_plan_file
        with open(my_plan_file, "rb") as f:
            print(f"Existing plan: {len(pickle.load(f))} stations "
                  f"(from {os.path.basename(my_plan_file)})")
        self.game_over = None
        self.budget = None
        self.plan_instance = None
        self.plan_length = None
        # 11 per-node features; index 10 is the grid slack added by the feasibility
        # layer (see establish_observation).
        self.row_length = 11
        self.best_score = None
        self.last_episode_best_score = 0
        self.best_plan = None
        self.best_node_list = None
        self.schritt = None
        self.config_dict = None
        self.previous_score = None
        self.feature_scaler = FeatureScaler(location=location)
        # 0-4: the original heuristics (build-by-benefit, build-by-demand,
        #      add-by-benefit, add-by-demand, relocate).
        # 5-6: grid-aware build and grid-relief relocate. These exist because
        #      filtering alone only makes the agent grid-safe *passively* -- it can
        #      be blocked, but it has no action that expresses "prefer the bus with
        #      room". 5 and 6 are that lever.
        self.grid_actions = (grid_mode == "hard") if grid_actions is None else bool(grid_actions)
        if self.grid_actions and self.grid_adapter is None:
            print("Warning: grid actions requested but no grid adapter is available; disabling them.")
            self.grid_actions = False
        self.action_space = spaces.Discrete(7 if self.grid_actions else 5)
        
        self.num_buses = len(self.grid_adapter.get_all_bus_capacities([])) if self.grid_adapter else 0

        # Precompute node-to-bus mapping for local grid capacities
        self.node_to_bus_idx = {}
        if self.grid_adapter:
            for node in self.node_list:
                lat = node[1].get('y', 0.0)
                lon = node[1].get('x', 0.0)
                bus_info = self.grid_adapter._get_bus_info(lat, lon)
                self.node_to_bus_idx[node[0]] = bus_info.get('bus_idx', -1)
            # Tell the adapter how many buses this district spans, so it can put the
            # capacity penalty on the same scale as the welfare term. Derived from
            # every node and fixed for the env's lifetime -- deliberately NOT the
            # buses some plan happens to load, which would drift during an episode.
            self.grid_adapter.set_district_scope(self.node_to_bus_idx.values())
            print(f"District grid scope: {self.grid_adapter._n_district_buses} buses "
                  f"across {len(self.node_list)} nodes.")

        # Charger-configuration lookup. Loaded here rather than in reset() because
        # it is static and the feasibility layer needs it to precompute how many MW
        # a new station at each node would draw.
        config_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                   "data", "processed", "config_lookup.json")
        self.config_dict = H.get_lookup(config_path)

        # Feasibility layer. Built whenever grid data exists -- even in "soft"/"off"
        # mode, where it enforces nothing but still supplies the observation's grid
        # slack feature and the per-bus utilisation metrics the evaluation reports.
        self.feasibility = None
        if self.grid_adapter:
            mw_cache = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                    "data", "Graph", location, "node_required_mw.pkl")
            self.feasibility = GridFeasibilityLayer(
                adapter=self.grid_adapter,
                node_list=self.node_list,
                node_to_bus_idx=self.node_to_bus_idx,
                charging_power_kw=H.CHARGING_POWER,
                config_dict=self.config_dict,
                initial_solution_fn=H.initial_solution,
                cache_path=mw_cache,
            )
            total_cap = sum(self.feasibility.base_headroom.values())
            print(f"Grid feasibility [{grid_mode}]: {len(self.feasibility.base_headroom)} buses, "
                  f"{total_cap:.1f} MW total headroom.")

        if self.obs_type == "mlp":
            shape = self.row_length * len(self.node_list) + self.N_GLOBAL
            self.observation_space = spaces.Box(low=-1.0, high=1.0, shape=(shape,), dtype=np.float32)
        elif self.obs_type == "mlp_graph":
            # MLP augmented with graph-derived features
            self.graph_augmentor = GraphFeatureAugmentor(
                self.node_list, _graph, self.node_id_to_idx
            )
            n_graph_summaries = GraphFeatureAugmentor.N_GRAPH_SUMMARIES
            # Per-node: original features + 1-hop aggregated features
            # Global: 3 global state + graph-level summaries
            shape = self.row_length * 2 * len(self.node_list) + self.N_GLOBAL + n_graph_summaries
            self.observation_space = spaces.Box(low=-1.0, high=1.0, shape=(shape,), dtype=np.float32)
        elif self.obs_type in ("gnn", "attention"):
            # "attention" (AttentionFeaturesExtractor) reuses this exact Dict space --
            # it ignores edge_index/edge_attr (treats nodes as a set, not a graph) but
            # keeping the space identical avoids duplicating the edge-array setup below
            # and keeps establish_observation()'s generic dict-return branch working
            # unchanged for both obs_types.
            edges = []
            edge_lengths = []
            for u, v, data in _graph.edges(data=True):
                if u in self.node_id_to_idx and v in self.node_id_to_idx:
                    edges.append([self.node_id_to_idx[u], self.node_id_to_idx[v]])
                    edge_lengths.append(data.get('length', 10.0))

            if edges:
                self.edge_index_array = np.array(edges, dtype=np.int32).T
                # Scale edge lengths once
                scaled_lengths = [self.feature_scaler.scale_road_length(l) for l in edge_lengths]
                self.edge_attr_array = np.array(scaled_lengths, dtype=np.float32).reshape(-1, 1)
            else:
                self.edge_index_array = np.zeros((2, 1), dtype=np.int32)
                self.edge_attr_array = np.zeros((1, 1), dtype=np.float32)

            self.observation_space = spaces.Dict({
                "node_features": spaces.Box(low=-1.0, high=1.0, shape=(len(self.node_list), self.row_length), dtype=np.float32),
                "edge_index": spaces.Box(low=0, high=len(self.node_list), shape=(2, self.edge_index_array.shape[1]), dtype=np.int32),
                "edge_attr": spaces.Box(low=-1.0, high=1.0, shape=(self.edge_attr_array.shape[0], 1), dtype=np.float32),
                "global_state": spaces.Box(low=-1.0, high=1.0, shape=(self.N_GLOBAL,), dtype=np.float32)
            })
        else:
            raise ValueError(f"Unknown obs_type: {self.obs_type}. Must be 'mlp', 'mlp_graph', 'gnn', or 'attention'")

    def reset(self, seed=None, options=None):
        """
        Reset the state of the environment to an initial state
        """
        # Handle the seed for Gymnasium compatibility
        if seed is not None:
            np.random.seed(seed)
            random.seed(seed)

        # Clear the node->station assignment left by the previous episode.
        # station_seeking is an iterative fixed point run only twice per step, so it
        # starts from whatever assignment it finds; without this, episode n+1 inherits
        # episode n and the same seed no longer reproduces the same episode. That made
        # evaluate_all.py's ranking depend on the order checkpoints were evaluated in,
        # and made its score disagree with compare_rl.py running the same checkpoint
        # on a fresh env. The distance caches are deliberately NOT cleared: they hold
        # deterministic shortest-path lookups and rebuilding them doubles episode time.
        for my_node in self.node_list:
            my_node[1]["charging station"] = None
            my_node[1]["distance"] = None

        if self.best_score is not None:
            self.last_episode_best_score = self.best_score

        self.budget = H.BUDGET
        self.game_over = False
        self.plan_instance = Plan(self.node_list, self.node_dict, self.cost_dict,
                                  self.plan_file, self.graph)
        # Extend node features with grid data (if available)
        if self.grid_adapter:
            station_nodes = [(s[0], s[2]["capability"]) for s in self.plan_instance.plan]
            self.node_list = self.grid_adapter.extend_node_features(self.node_list, station_nodes)
        if self.feasibility:
            self.feasibility.refresh(self.plan_instance.plan)
            self.feasibility.blocked_actions = 0
            self.feasibility.redirected_actions = 0
        if self.grid_adapter and self.use_grid_penalty:
            dist_penalty, cap_penalty, grid_utilization, grid_distance = self.grid_adapter.calculate_grid_penalty(station_nodes)
            total_grid_penalty = {'dist_penalty': dist_penalty, 'cap_penalty': cap_penalty}
            self.best_score, _, _, _, _, _, _ = H.norm_score(self.plan_instance.plan, self.node_list,
                                                             self.plan_instance.norm_benefit, self.plan_instance.norm_charg,
                                                             self.plan_instance.norm_wait, self.plan_instance.norm_travel,
                                                             total_grid_penalty)
        else:
            self.best_score, _, _, _, _, _, _ = H.norm_score(self.plan_instance.plan, self.node_list,
                                                             self.plan_instance.norm_benefit, self.plan_instance.norm_charg,
                                                             self.plan_instance.norm_wait, self.plan_instance.norm_travel)

        self.previous_score = self.best_score
        self.starting_score = self.best_score  # baseline for the entire episode

        # self.best_score = max(self.best_score, -25)
        self.plan_length = len(self.plan_instance.existing_plan)
        self.schritt = 0
        self.best_plan = []
        self.best_node_list = []
        # self.config_dict is loaded once in __init__ (it is static).
        H.coverage(self.node_list, self.plan_instance.plan)
        obs = self.establish_observation()

        # Return obs AND an empty info dict (Required by new SB3/Gymnasium)
        return obs, {}

    def _init(self, my_node):
        self.node_dict[my_node[0]] = {}  # prepare node_dict
        self.cost_dict[my_node[0]] = {}
        my_node[1]["charging station"] = None
        my_node[1]["distance"] = None
        return my_node

    def establish_observation(self):
        """
        Build observation matrix (MLP) or Dict (GNN)
        """
        # Precompute capability dict to avoid nested lookups
        station_caps = {s[0][0]: s[2]["capability"] for s in self.plan_instance.plan}

        # Precompute distances to nearest existing station
        station_nodes = [s[0][0] for s in self.plan_instance.plan]
        if station_nodes:
            nearest_dists = []
            for node in self.node_list:
                dist = node[1].get("distance", self.feature_scaler.dist_to_station_max)
                nearest_dists.append(dist)
        else:
            nearest_dists = [self.feature_scaler.dist_to_station_max] * len(self.node_list)

        # Local bus capacity, read straight off the feasibility layer. It already
        # holds base headroom minus the current plan's load for exactly the district
        # buses, so this replaces a per-step scan of every 22 kV bus in the city AND
        # guarantees the number the agent sees is the same one the constraint uses.
        bus_caps = {}
        if self.feasibility:
            for bus_idx in self.feasibility.base_headroom:
                bus_caps[bus_idx] = max(0.0, self.feasibility.headroom(bus_idx))

        node_features = np.zeros((len(self.node_list), self.row_length), dtype=np.float32)

        for j, node in enumerate(self.node_list):
            # 0: longitude (scaled)
            node_features[j, 0] = self.feature_scaler.scale_lon(node[1].get('x', 105.8))
            # 1: latitude (scaled)
            node_features[j, 1] = self.feature_scaler.scale_lat(node[1].get('y', 21.0))
            # 2: static demand (representing baseline population)
            node_features[j, 2] = self.feature_scaler.scale_demand(node[1].get('demand', 0.0))
            # 3: dynamic demand (unsatisfied demand)
            dyn_demand = H.dynamic_demand(node, self.plan_instance.plan)
            node_features[j, 3] = self.feature_scaler.scale_demand(dyn_demand)
            # 4: land price
            node_features[j, 4] = self.feature_scaler.scale_land_price(node[1].get('land_price', 90.0))
            # 5: street count
            node_features[j, 5] = self.feature_scaler.scale_street_count(node[1].get('street_count', 3))
            # 6: current station capability at this node
            capability = station_caps.get(node[0], 0.0)
            node_features[j, 6] = self.feature_scaler.scale_capability(capability)
            # 7: grid distance
            grid_dist = node[1].get('grid_distance_km', -1.0)
            if grid_dist == float('inf') or np.isinf(grid_dist) or grid_dist == -1.0:
                node_features[j, 7] = -1.0
            else:
                node_features[j, 7] = self.feature_scaler.scale_grid_distance(grid_dist)
            # 8: local bus capacity
            bus_idx = self.node_to_bus_idx.get(node[0], -1)
            bus_cap = bus_caps.get(bus_idx, 0.0) if bus_idx != -1 else 0.0
            node_features[j, 8] = self.feature_scaler.scale_grid_mw(bus_cap)
            # 9: distance to nearest station
            nearest_dist = nearest_dists[j]
            node_features[j, 9] = self.feature_scaler.scale_nearest_station_dist(nearest_dist) if nearest_dist != self.feature_scaler.dist_to_station_max else -1.0
            # 10: grid slack -- how much of this node's bus capacity would be LEFT
            # after building a default station here, as a fraction of that bus's
            # capacity. Signed on purpose: negative means infeasible, and the
            # magnitude says by how much, so the agent sees a bus filling up
            # several steps before it is actually blocked. A boolean flag would
            # only tell it after the fact.
            if self.feasibility:
                bus_idx = self.feasibility.bus_of(node)
                base = self.feasibility.base_headroom.get(bus_idx, 0.0)
                if bus_idx == self.feasibility.NO_BUS or base <= 0.0:
                    node_features[j, 10] = -1.0
                else:
                    slack = (self.feasibility.headroom(bus_idx)
                             - self.feasibility.required_mw_new_station(node)) / base
                    node_features[j, 10] = float(np.clip(slack, -1.0, 1.0))
            else:
                node_features[j, 10] = 1.0

        # Global state
        budget_scaled = self.feature_scaler.scale_budget(self.budget)
        progress_scaled = 2.0 * (self.schritt / max(1.0, self.max_steps)) - 1.0
        # Clipped: observation_space is Box(-1, 1) and an unusually good episode can
        # push the raw delta past 1, which silently puts the observation outside its
        # declared space.
        score_delta = float(np.clip(self.best_score - self.starting_score, -1.0, 1.0))
        if self.feasibility:
            # Tightest bus in the district: the binding constraint, and the one number
            # that tells the agent the grid is running out before any single node does.
            min_headroom = 2.0 * self.feasibility.min_headroom_ratio() - 1.0
            free_nodes = [n for n in self.node_list if n[0] not in station_caps]
            feasible_frac = 2.0 * self.feasibility.feasible_fraction(free_nodes) - 1.0
        else:
            min_headroom, feasible_frac = 1.0, 1.0
        global_st = np.array([budget_scaled, progress_scaled, score_delta,
                              min_headroom, feasible_frac], dtype=np.float32)

        if self.obs_type == "mlp":
            obs = np.concatenate([node_features.flatten(), global_st])
            return obs
        elif self.obs_type == "mlp_graph":
            # Augment with 1-hop neighborhood features
            hop1_features = self.graph_augmentor.compute_hop1_features(node_features)
            augmented = np.concatenate([node_features, hop1_features], axis=1)  # (N, 2F)
            # Graph-level summary statistics
            graph_summaries = self.graph_augmentor.compute_graph_summaries(node_features)
            obs = np.concatenate([augmented.flatten(), global_st, graph_summaries])
            return obs
        else:
            return {
                "node_features": node_features,
                "edge_index": self.edge_index_array,
                "edge_attr": self.edge_attr_array,
                "global_state": global_st
            }

    def budget_adjustment(self, my_station):
        inst_cost = my_station[2]["fee"]
        if self.budget - inst_cost >= 0:
            # if we have enough money, we build the station
            self.budget -= inst_cost
        else:
            self.game_over = True

    def budget_adjustment_small(self, chosen_node, config_index):
        single_charger_budget = H.evs_parking_area * chosen_node[1]['land_price'] + H.INSTALL_FEE[config_index]
        if self.budget - single_charger_budget >= 0:
            # if we have enough money, we build the charger
            self.budget -= single_charger_budget
        else:
            self.game_over = True

    def prepare_score(self):
        """
        We have to make a loop to reorganise the station assignment
        """
        for j in range(2):
            self.node_list, _, _ = H.station_seeking(self.plan_instance.plan, self.node_list,
                                                      self.node_dict,
                                                      self.cost_dict,
                                                      self.graph)

        
    def step(self, my_action):
        """
        Perform a step in the episode
        """
        for station in self.plan_instance.plan:
            # if there is an empty station, delete it
            if np.sum(station[1]) <= 0:
                self.plan_instance.remove_plan(station)

        # Per-bus load must reflect the plan as it stands BEFORE the action, because
        # _control_action filters candidates against it.
        if self.feasibility:
            self.feasibility.refresh(self.plan_instance.plan)

        chosen_node, free_list_zero, config_index, action = self._control_action(my_action)
        if chosen_node is None:
            # No feasible placement anywhere for this action: every bus its
            # candidates could reach is full. The step is a no-op, not a violation
            # and not a termination. Ending the episode here (as an earlier attempt
            # did) is what destroys credit assignment: it makes "the grid is full"
            # indistinguishable from "the agent failed", and the fastest way to stop
            # collecting negative reward becomes to stop building at all.
            if self.feasibility:
                self.feasibility.blocked_actions += 1
        elif chosen_node in free_list_zero:
            # build new station
            default_config = H.initial_solution(self.config_dict, self.node_list, chosen_node)
            station_instance = Station()
            station_instance.add_position(chosen_node)
            station_instance.add_chargers(default_config.copy())
            station_instance.establish_dictionnary(self.node_list)
            # Step: Control budget
            self.budget_adjustment(station_instance.station)
            if not self.game_over:
                self.plan_instance.add_plan(station_instance.station) # this must be the reason why the budget exceed 100%
        else:
            # add column to existing CS
            station_index = None
            for station in self.plan_instance.plan:
                if station[0][0] == chosen_node[0]:
                    station_index = self.plan_instance.plan.index(station)
                    break
            # Step: Control budget
            self.budget_adjustment_small(chosen_node, config_index)
            if not self.game_over:
                self.plan_instance.plan[station_index][1][config_index] += 1

        # update station capacity
        for station in self.plan_instance.plan:
            H.s_dictionnary(station, self.node_list)

        # Extend node features with grid data (if available)
        if self.grid_adapter:
            station_nodes = [(s[0], s[2]["capability"]) for s in self.plan_instance.plan]
            self.node_list = self.grid_adapter.extend_node_features(self.node_list, station_nodes)
        if self.feasibility:
            self.feasibility.refresh(self.plan_instance.plan)
            if self.use_hard_constraint and self.verify_grid:
                violated = self.feasibility.violated_buses()
                assert not violated, f"hard constraint broken at step {self.schritt}: {violated}"

        # Step: calculate reward normally (including soft penalty from grid)
        reward = self.evaluation()

        H.coverage(self.node_list, self.plan_instance.plan)
        obs = self.establish_observation()
        # episode end conditions
        if len(self.plan_instance.plan) == len(self.node_list):
            self.game_over = True
        self.schritt += 1
        if self.schritt >= self.max_steps:
            self.game_over = True

        # NOTE: no terminal bonus here. best_bonus in evaluation() already telescopes
        # to exactly (best_score_final - starting_score) over the episode, so a
        # terminal bonus of the same quantity would just re-add that signal a
        # second (or third) time rather than convey new information.

        # Return gymnasium format: (obs, reward, terminated, truncated, info)
        return obs, reward, self.game_over, False, {}

    def station_config_check(self, my_station):
        """
        no more than K chargers are allowed at the station
        """
        capacity = True
        if sum(my_station[1]) >= H.K:
            capacity = False
        return capacity

    def _headroom_ratio_of(self, node):
        """Remaining fraction of capacity at the bus this node connects to."""
        return self.feasibility.headroom_ratio(self.feasibility.bus_of(node))

    def _control_action(self, chosen_action):
        """
        Resolve an action into a concrete node.

        The agent names a strategy, not a location -- helpers.py picks the node.
        That is why a capacity *penalty* alone cannot work: none of these
        heuristics can see the grid, so no reward can make the policy prefer a
        bus with headroom. The fix is here rather than in the reward: every
        candidate list is filtered through the feasibility layer before the
        heuristic ranks it, so whichever node comes back is one the grid can
        actually serve.

        When a strategy's own candidate list is empty the action is redirected to
        the nearest strategy that still has one (build -> add, add -> build)
        instead of being wasted; only when nothing at all is placeable does it
        return None, which step() treats as a no-op.

        Returns:
            (chosen_node | None, free_list, config_index, action)
        """
        my_action = chosen_action
        config_index = None
        full_station_list = [s[0][0] for s in self.plan_instance.plan if self.station_config_check(s)
                             is False]  # these are the stations with exactly K chargers
        station_list = [s[0][0] for s in self.plan_instance.plan]  # all charging stations
        occupied_list = [node for node in self.node_list if node[0] not in full_station_list and node[0] in
                         station_list]  # nodes with non-full stations
        free_list = [node for node in self.node_list if node[0] not in station_list]  # nodes without stations

        hard = self.use_hard_constraint and self.feasibility is not None
        cand_free = self.feasibility.feasible_free(free_list) if hard else free_list

        def redirected():
            if self.feasibility:
                self.feasibility.redirected_actions += 1

        if 0 <= my_action <= 1:
            # ---- build a new station ------------------------------------------
            if not cand_free:
                # No bus can take a whole new station. Adding a charger to an
                # existing one needs ~50x less power, so it usually still fits:
                # degrade to that rather than burn the step.
                config_index = 3
                cand_occ = self.feasibility.feasible_occupied(occupied_list, config_index) if hard else occupied_list
                if not cand_occ:
                    return None, free_list, None, my_action
                redirected()
                chosen_node = H.choose_node_new_benefit(cand_occ, self.node_list)
                return chosen_node, free_list, config_index, my_action
            if my_action == 0:
                chosen_node = H.choose_node_new_benefit(cand_free, self.node_list)
            else:
                chosen_node = H.choose_node_bydemand(cand_free, self.plan_instance.plan)

        elif 2 <= my_action <= 3:
            # ---- add a charger to an existing station --------------------------
            config_index = 3
            cand_occ = self.feasibility.feasible_occupied(occupied_list, config_index) if hard else occupied_list
            if not cand_occ:
                # Every existing station sits on a full bus. Falling back to a new
                # station elsewhere keeps the step useful; if that is impossible
                # too, the grid is genuinely saturated.
                if not cand_free:
                    return None, free_list, None, my_action
                redirected()
                return H.choose_node_new_benefit(cand_free, self.node_list), free_list, None, my_action
            if my_action == 2:
                chosen_node = H.choose_node_new_benefit(cand_occ, self.node_list)
            else:
                cand_ids = {n[0] for n in cand_occ}
                cand_plan = [s for s in self.plan_instance.plan if s[0][0] in cand_ids]
                chosen_node = H.choose_node_bydemand(cand_occ, cand_plan, add=True)

        elif my_action == 4:
            # ---- relocate a charger (original: from the least useful station) ---
            steal_plan = [s for s in self.plan_instance.plan if s[0] not in self.plan_instance.existing_plan]
            # we can not steal from the existing charging plan
            stolen_station = H.anti_choose_node_bybenefit(self.node_list, steal_plan)
            if stolen_station is None:
                # only necessary if we take this action in the very beginning
                if not cand_free:
                    return None, free_list, None, my_action
                chosen_node = choice(cand_free)
            else:
                self.budget, config_index = self.plan_instance.steal_column(stolen_station, self.budget)
                chosen_node = self._relocation_target(free_list, config_index, hard)

        elif my_action == 5:
            # ---- grid-aware build ----------------------------------------------
            # The one action that trades demand against headroom explicitly. With
            # only actions 0-4 the agent can be *blocked* by the grid but never
            # *anticipate* it, so it keeps filling the densest bus until it is full
            # and then has nowhere good left to go.
            if not cand_free:
                return None, free_list, None, my_action
            chosen_node = H.choose_node_grid_aware(cand_free, self.plan_instance.plan,
                                                   self._headroom_ratio_of, H.GRID_HEADROOM_WEIGHT)

        else:
            # ---- grid-relief relocate (action 6) --------------------------------
            # Filtering can only stop a bus getting worse. This is the only way to
            # make an already-tight bus better, which matters because the early,
            # greedy part of an episode is exactly when the agent over-commits to
            # the dense bus.
            steal_plan = [s for s in self.plan_instance.plan if s[0] not in self.plan_instance.existing_plan]
            stolen_station = H.anti_choose_node_bygrid(self.node_list, steal_plan, self._headroom_ratio_of)
            if stolen_station is None:
                if not cand_free:
                    return None, free_list, None, my_action
                redirected()
                chosen_node = H.choose_node_grid_aware(cand_free, self.plan_instance.plan,
                                                       self._headroom_ratio_of, H.GRID_HEADROOM_WEIGHT)
            else:
                self.budget, config_index = self.plan_instance.steal_column(stolen_station, self.budget)
                chosen_node = self._relocation_target(free_list, config_index, hard, grid_aware=True)

        return chosen_node, free_list, config_index, my_action

    def _relocation_target(self, free_list, config_index, hard, grid_aware=False):
        """
        Pick where a just-stolen charger goes.

        Called only AFTER steal_column() has already mutated the plan, so the
        feasibility layer is re-read here: the theft freed capacity at the source
        bus, and a destination that was infeasible a moment ago may now fit. If
        nothing fits, returning None is a legitimate outcome -- the charger has
        been removed and the grid is that much less loaded, which is exactly what
        this action is for.
        """
        if hard:
            self.feasibility.refresh(self.plan_instance.plan)
        cand_free = self.feasibility.feasible_free(free_list) if hard else free_list

        if grid_aware:
            return H.choose_node_grid_aware(cand_free, self.plan_instance.plan,
                                            self._headroom_ratio_of, H.GRID_HEADROOM_WEIGHT) if cand_free else None

        # support_stations() may return either an existing station (add a charger
        # there) or a free node (build there). Restricting BOTH of its inputs to
        # feasible members is what makes either outcome safe.
        plan_ok = (self.feasibility.feasible_stations(self.plan_instance.plan, config_index)
                   if hard else self.plan_instance.plan)
        if not cand_free:
            # With no free node to fall back on, support_stations() must be able to
            # return a station directly -- so only offer it stations that can still
            # take a charger (its other branch does min() over the free list).
            plan_ok = [st for st in plan_ok if self.station_config_check(st)]
        if not plan_ok:
            return choice(cand_free) if cand_free else None
        return H.support_stations(plan_ok, cand_free)

    def evaluation(self, bonus_w=3.0):
        """
        Calculate the reward.
        Reward is aligned with the score objective to prevent reward-score divergence.
        """
        self.prepare_score()

        if self.grid_adapter and self.use_grid_penalty:
            station_nodes = [(s[0], s[2]["capability"]) for s in self.plan_instance.plan]
            dist_penalty, cap_penalty, grid_utilization, grid_distance = self.grid_adapter.calculate_grid_penalty(station_nodes)
            total_grid_penalty = {'dist_penalty': dist_penalty, 'cap_penalty': cap_penalty}
            new_score, _, _, _, _, _, _ = H.norm_score(self.plan_instance.plan, self.node_list,
                                                       self.plan_instance.norm_benefit, self.plan_instance.norm_charg,
                                                       self.plan_instance.norm_wait, self.plan_instance.norm_travel,
                                                       total_grid_penalty)
        else:
            new_score, _, _, _, _, _, _ = H.norm_score(self.plan_instance.plan, self.node_list,
                                                       self.plan_instance.norm_benefit, self.plan_instance.norm_charg,
                                                       self.plan_instance.norm_wait, self.plan_instance.norm_travel)

        shaping = new_score - self.previous_score
        self.previous_score = new_score
        best_gain = max(0.0, new_score - self.best_score)
        if best_gain > 0.0:
            self.best_score = new_score
            self.best_plan = copy.deepcopy(self.plan_instance.plan)
            self.best_node_list = copy.deepcopy(self.node_list)

        reward = shaping + bonus_w * best_gain
        return reward

    def _print_grid_violations(self, station_nodes):
        """
        Print detailed grid violation information for debugging.
        """
        if not self.grid_adapter:
            return
            
        bus_loads = {}
        print("\n[GRID CONSTRAINT DETAILS]")
        print("Bus-wise Load Analysis:")
        print("-" * 80)
        print(f"{'Bus ID':>8} {'Required (MW)':>15} {'Available (MW)':>15} {'Status':>15}")
        print("-" * 80)
        
        # Reconstruct bus loads to display
        for item in station_nodes:
            if isinstance(item, tuple) and len(item) == 2 and isinstance(item[1], (int, float)):
                node, capacity_mw = item
                result = self.grid_adapter.check_feasibility(node, actual_power_mw=capacity_mw)
            else:
                node = item
                result = self.grid_adapter.check_feasibility(node)
            
            bus_idx = result.get('bus_idx', -1)
            if bus_idx != -1:
                if bus_idx not in bus_loads:
                    bus_loads[bus_idx] = {'required': 0.0, 'available': result['available_mw']}
                bus_loads[bus_idx]['required'] += result['required_mw']
        
        # Print violations
        for bus_idx, data in sorted(bus_loads.items()):
            required = data['required']
            available = data['available']
            remaining = available - required
            status = "✓ OK" if remaining >= 0 else "✗ VIOLATED"
            print(f"{bus_idx:>8} {required:>15.3f} {available:>15.3f} {status:>15}")
        print("-" * 80)

    def render(self, mode='human', close=False):
        """
        Render the environment to the screen
        """
        print(f'Score is: {self.best_score}')
        print(f'Number of stations in charging plan: {len(self.plan_instance.plan)}')
        return self.best_node_list, self.best_plan


if __name__ == '__main__':
    location = "DongDa"
    graph_file = os.path.join(current_dir, "data", "Graph", location, location + ".graphml")
    node_file = os.path.join(current_dir, "data", "Graph", location, "nodes_extended_" + location + ".txt")
    plan_file = os.path.join(current_dir, "data", "Graph", location, "existingplan_" + location + ".pkl")
    env = StationPlacement(graph_file, node_file, plan_file, location=location)
    # It will check your custom environment and output additional warnings if needed
    check_env(env)
