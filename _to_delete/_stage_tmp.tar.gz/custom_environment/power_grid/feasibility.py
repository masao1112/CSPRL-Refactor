"""
Grid feasibility layer.

Turns the 22 kV bus-capacity limit from a *soft reward penalty* into a *hard
constraint enforced by construction*.

WHY THIS EXISTS
---------------
StationPlacement's action space does not name a node: the agent picks a
heuristic (build-by-benefit, build-by-demand, add-charger, relocate) and
helpers.py picks the node. Those heuristics are blind to the power grid, so a
policy has no way to express "put this station on a bus that still has
headroom" -- no reward shaping can teach a behaviour the policy cannot
represent. The observed failure mode is that a capacity penalty teaches the
only grid-safe behaviour that IS representable: stop building. (Empirically:
10 stations / 36% budget with the penalty on, vs 57 without it.)

This layer fixes the representation instead of the reward. It filters the
candidate node list *before* the heuristic runs, so every action the agent can
take leaves every bus within its limit. Violations become impossible rather
than expensive, and the agent's remaining problem -- choosing well among
feasible placements -- is exactly the grid-aware trade-off we want it to learn.

UNITS
-----
Everything here is in "required MW", i.e. nameplate MW inflated by
CAPACITY_SAFETY_MARGIN, matching CSPRLGridAdapter.check_feasibility. Headroom
comes from GridLoader.get_available_capacity(bus)['available_mw'], the same
number calculate_grid_penalty compares against, so "feasible here" and
"cap_penalty == 0" are guaranteed to agree.
"""

import os
import pickle
from collections import defaultdict
from typing import Dict, Iterable, List, Optional, Sequence

import numpy as np

from .csprl_adapter import CAPACITY_SAFETY_MARGIN


class GridFeasibilityLayer:
    """
    Incremental bus-load bookkeeping plus feasibility predicates.

    The layer holds two maps keyed by pandapower bus index:
      base_headroom[b] -- MW available at bus b before any agent-built station.
                          Constant for the env's lifetime.
      used[b]          -- required MW of the CURRENT plan's stations at bus b.
                          Recomputed from the plan on every refresh() rather
                          than mutated incrementally: the plan is short (tens of
                          stations) so the recompute is cheap, and it cannot
                          drift out of sync the way an incremental counter can
                          when a station is removed by steal_column().
    """

    #: Buses whose index is -1 (no 22 kV bus found near the node) are outside the
    #: grid model. calculate_grid_penalty also skips them, so treating them as
    #: unconstrained here keeps the layer and the penalty consistent.
    NO_BUS = -1

    def __init__(
            self,
            adapter,
            node_list: List,
            node_to_bus_idx: Dict,
            charging_power_kw: Sequence[float],
            config_dict: Dict,
            initial_solution_fn,
            cache_path: Optional[str] = None,
            safety_margin: float = CAPACITY_SAFETY_MARGIN,
    ):
        self.adapter = adapter
        self.node_to_bus_idx = node_to_bus_idx
        self.safety_margin = safety_margin
        self.charger_mw = np.asarray(charging_power_kw, dtype=np.float64) / 1000.0

        # ---- base headroom per bus (constant) --------------------------------
        self.base_headroom: Dict[int, float] = {}
        for bus_idx in {b for b in node_to_bus_idx.values() if b != self.NO_BUS}:
            info = adapter.loader.get_available_capacity(bus_idx)
            self.base_headroom[bus_idx] = float(info.get("available_mw", 0.0))

        # ---- required MW of a *new* station at each node (constant) ----------
        # initial_solution() depends only on static demand within RADIUS_MAX, so
        # the default config at a node never changes during an episode. It is
        # O(N^2) haversine to compute for every node, which is why it is done
        # once here and cached to disk -- otherwise every VecEnv worker and every
        # checkpoint evaluated by evaluate_all.py would pay it again.
        self.node_required_mw: Dict = self._load_or_build_node_mw(
            node_list, config_dict, initial_solution_fn, cache_path
        )

        self.used: Dict[int, float] = defaultdict(float)
        #: How often a chosen action found no feasible candidate this episode.
        #: Exposed as a metric: a policy that keeps hitting this is one the grid
        #: has saturated, which is information, not a bug.
        self.blocked_actions = 0
        #: How often an action was redirected to a different strategy because its
        #: own candidate list was empty (build -> add, or add -> build).
        self.redirected_actions = 0

    # ------------------------------------------------------------------ setup

    def _load_or_build_node_mw(self, node_list, config_dict, initial_solution_fn, cache_path):
        signature = (len(node_list), len(config_dict), round(self.safety_margin, 6))
        if cache_path and os.path.exists(cache_path):
            try:
                with open(cache_path, "rb") as f:
                    blob = pickle.load(f)
                if blob.get("signature") == signature:
                    return blob["data"]
                print("Node-MW cache is stale (node/config set changed) - recomputing.")
            except Exception as e:
                print(f"Warning: could not load node-MW cache: {e}")

        data = {}
        for node in node_list:
            config = initial_solution_fn(config_dict, node_list, node)
            nameplate_mw = float(np.sum(self.charger_mw * np.asarray(config, dtype=np.float64)))
            data[node[0]] = nameplate_mw * (1.0 + self.safety_margin)

        if cache_path:
            try:
                os.makedirs(os.path.dirname(cache_path), exist_ok=True)
                with open(cache_path, "wb") as f:
                    pickle.dump({"signature": signature, "data": data}, f)
            except Exception as e:
                print(f"Warning: could not write node-MW cache: {e}")
        return data

    # -------------------------------------------------------------- bookkeeping

    def refresh(self, plan) -> None:
        """Recompute per-bus load from the current plan. Call once per step,
        after the plan has been mutated and s_dictionnary() re-run."""
        self.used = defaultdict(float)
        for station in plan:
            bus_idx = self.node_to_bus_idx.get(station[0][0], self.NO_BUS)
            if bus_idx == self.NO_BUS:
                continue
            self.used[bus_idx] += station[2]["capability"] * (1.0 + self.safety_margin)

    def bus_of(self, node) -> int:
        return self.node_to_bus_idx.get(node[0], self.NO_BUS)

    def headroom(self, bus_idx: int) -> float:
        if bus_idx == self.NO_BUS:
            return float("inf")
        return self.base_headroom.get(bus_idx, 0.0) - self.used.get(bus_idx, 0.0)

    def headroom_ratio(self, bus_idx: int) -> float:
        """Remaining fraction of the bus's own capacity, in [0, 1]."""
        if bus_idx == self.NO_BUS:
            return 1.0
        base = self.base_headroom.get(bus_idx, 0.0)
        if base <= 0.0:
            return 0.0
        return float(np.clip(self.headroom(bus_idx) / base, 0.0, 1.0))

    # -------------------------------------------------------------- predicates

    def required_mw_new_station(self, node) -> float:
        return self.node_required_mw.get(node[0], 0.0)

    def required_mw_charger(self, config_index: int) -> float:
        return float(self.charger_mw[config_index]) * (1.0 + self.safety_margin)

    def can_build(self, node) -> bool:
        """Can a NEW station with its default config go at this node?"""
        return self.headroom(self.bus_of(node)) >= self.required_mw_new_station(node)

    def can_add(self, node, config_index: int) -> bool:
        """Can one more charger of this type go at an EXISTING station here?"""
        return self.headroom(self.bus_of(node)) >= self.required_mw_charger(config_index)

    # ------------------------------------------------------------------ filters

    def feasible_free(self, free_list: List) -> List:
        return [n for n in free_list if self.can_build(n)]

    def feasible_occupied(self, occupied_list: List, config_index: int) -> List:
        return [n for n in occupied_list if self.can_add(n, config_index)]

    def feasible_stations(self, plan: List, config_index: int) -> List:
        """Subset of the plan whose bus can absorb one more charger."""
        return [s for s in plan if self.can_add(s[0], config_index)]

    # ------------------------------------------------------------------ metrics

    def feasible_fraction(self, free_list: List) -> float:
        if not free_list:
            return 0.0
        return len(self.feasible_free(free_list)) / len(free_list)

    def min_headroom_ratio(self) -> float:
        if not self.base_headroom:
            return 1.0
        return min(self.headroom_ratio(b) for b in self.base_headroom)

    def worst_utilization(self) -> float:
        """Highest load/capacity ratio over district buses. Must stay <= 1.0
        whenever the hard constraint is active."""
        worst = 0.0
        for bus_idx, base in self.base_headroom.items():
            if base <= 0.0:
                continue
            worst = max(worst, self.used.get(bus_idx, 0.0) / base)
        return worst

    def load_spread(self) -> float:
        """Coefficient of variation of per-bus utilization. Lower means the plan
        spreads load across buses instead of piling it on the dense one."""
        if not self.base_headroom:
            return 0.0
        utils = np.array([
            self.used.get(b, 0.0) / base
            for b, base in self.base_headroom.items() if base > 0.0
        ])
        if utils.size == 0 or utils.mean() <= 1e-9:
            return 0.0
        return float(utils.std() / utils.mean())

    def violated_buses(self) -> List[Dict]:
        """Buses over their limit. The hard-constraint invariant is that this is
        empty after every step; verify_grid mode asserts on it."""
        out = []
        for bus_idx, base in self.base_headroom.items():
            used = self.used.get(bus_idx, 0.0)
            if used > base:
                out.append({"bus_idx": bus_idx, "used_mw": used,
                            "capacity_mw": base, "overload_mw": used - base})
        return out
