from stable_baselines3 import DQN, PPO
from stable_baselines3.common.monitor import Monitor
from stable_baselines3.common.results_plotter import load_results, ts2xy
from stable_baselines3.common.callbacks import BaseCallback
from stable_baselines3.common.utils import LinearSchedule
import os
import numpy as np
import torch
import random
import csv
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from collections import deque
from custom_environment.StationPlacementEnv import StationPlacement
import custom_environment.helpers as H

"""
Trai the model by reinforcement learning.
"""

class SaveOnBestTrainingRewardCallback(BaseCallback):
    """
    Code from Stable Baselines3,
    https://colab.research.google.com/github/Stable-Baselines-Team/rl-colab-notebooks/blob/sb3/monitor_training.ipynb
    Callback for saving a model (the check is done every ``check_freq`` steps)
    based on the training reward (in practice, we recommend using ``EvalCallback``).

    :param check_freq: (int)
    :param my_log_dir: (str) Path to the folder where the model will be saved.
      It must contains the file created by the ``Monitor`` wrapper.
    :param verbose: (int)
    """

    def __init__(self, check_freq: int, my_log_dir: str, my_modelname: str, verbose=1):
        super(SaveOnBestTrainingRewardCallback, self).__init__(verbose)
        self.check_freq = check_freq
        self.log_dir = my_log_dir
        self.modelname = my_modelname
        self.save_path = os.path.join(self.log_dir, self.modelname)
        self.rewards = deque(maxlen=5)
        self.best_mean_reward = -np.inf
        self.best_env_score = -np.inf
        self.n_episodes = 0
        # Episode history for plotting
        self.episode_rewards = []    # total reward per episode
        self.episode_best_scores = []  # best_score per episode

    def _init_callback(self) -> None:
        # Create folder if needed
        if self.log_dir is not None:
            os.makedirs(self.log_dir, exist_ok=True)

    def _on_step(self) -> bool:
        # Check if an episode finished
        if self.locals["dones"][0]:
            self.n_episodes += 1
            
            # Access current learning rate from optimizer
            lr = self.model.policy.optimizer.param_groups[0]["lr"]
            
            # Query the environment for the best_score
            try:
                # training_env is usually a VecEnv in SB3
                env_best_score = self.training_env.get_attr('last_episode_best_score')[0]
            except Exception:
                env_best_score = -np.inf

            # Get total episode reward from Monitor wrapper
            info = self.locals["infos"][0]
            episode_reward = info.get("episode", {}).get("r", 0.0) if info else 0.0

            # Record history
            self.episode_rewards.append(episode_reward)
            self.episode_best_scores.append(env_best_score)

            # Store reward for mean calculation
            self.rewards.append(episode_reward)

            if self.n_episodes % self.check_freq == 0:
                # Mean training reward over the last check_freq episodes
                my_mean_reward = np.mean(self.rewards)

                if self.verbose > 0:
                    print("-" * 20)
                    print("Num timesteps: {}, Episode: {}".format(self.num_timesteps, self.n_episodes))
                    print("Current LR: {:.2e}".format(lr))
                    print("Reward  -> Current: {:.3f} | Mean: {:.3f} | Best Mean: {:.3f}".format(
                        episode_reward, my_mean_reward, self.best_mean_reward))
                    print("Score   -> Current: {:.6f} | Best: {:.6f}".format(
                        env_best_score, self.best_env_score))

                # Save by best mean reward (original criterion)
                new_best_mean = my_mean_reward > self.best_mean_reward
                if new_best_mean:
                    new_name = self.modelname + str(self.num_timesteps)
                    if self.log_dir is not None:
                        os.makedirs(self.log_dir, exist_ok=True)
                    self.save_path = os.path.join(self.log_dir, new_name)
                    print(">>> New best mean REWARD: {:.3f}. Saving to {}".format(my_mean_reward, self.save_path))
                    self.best_mean_reward = my_mean_reward
                    self.model.save(self.save_path)

                # Save by best score (new criterion - preserves peak performance)
                if env_best_score > self.best_env_score and not new_best_mean:
                    self.best_env_score = env_best_score
                    score_save_path = os.path.join(self.log_dir, self.modelname + str(self.num_timesteps))
                    print(">>> New best SCORE: {:.6f}. Saving to {}".format(env_best_score, score_save_path))
                    self.model.save(score_save_path)

        return True

    def save_history(self, path: str):
        """Save episode history to a CSV file."""
        os.makedirs(path, exist_ok=True)
        csv_path = os.path.join(path, "episode_history.csv")
        with open(csv_path, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["episode", "total_reward", "best_score"])
            for i, (r, s) in enumerate(zip(self.episode_rewards, self.episode_best_scores), 1):
                writer.writerow([i, r, s])
        if self.verbose > 0:
            print(f"Episode history saved to {csv_path}")

    def plot_history(self, path: str):
        """Plot total reward and best score per episode and save the figure."""
        if not self.episode_rewards:
            return

        episodes = np.arange(1, len(self.episode_rewards) + 1)
        rewards = np.array(self.episode_rewards)
        best_scores = np.array(self.episode_best_scores)

        fig, ax1 = plt.subplots(figsize=(12, 5))

        color_reward = "#3b82f6"   # blue
        color_score = "#ef4444"    # red

        # Plot total reward
        ax1.set_xlabel("Episode")
        ax1.set_ylabel("Total Reward", color=color_reward)
        ax1.plot(episodes, rewards, color=color_reward, alpha=0.3, linewidth=0.8, label="Total Reward")
        # Smoothed (rolling mean, window=10)
        if len(rewards) >= 10:
            smooth_r = np.convolve(rewards, np.ones(10) / 10, mode="valid")
            ax1.plot(episodes[9:], smooth_r, color=color_reward, linewidth=2, label="Reward (MA-10)")
        ax1.tick_params(axis="y", labelcolor=color_reward)
        ax1.legend(loc="upper left")

        # Plot best score on secondary y-axis
        ax2 = ax1.twinx()
        ax2.set_ylabel("Best Score", color=color_score)
        ax2.plot(episodes, best_scores, color=color_score, alpha=0.3, linewidth=0.8, label="Best Score")
        if len(best_scores) >= 10:
            smooth_s = np.convolve(best_scores, np.ones(10) / 10, mode="valid")
            ax2.plot(episodes[9:], smooth_s, color=color_score, linewidth=2, label="Best Score (MA-10)")
        ax2.tick_params(axis="y", labelcolor=color_score)
        ax2.legend(loc="upper right")

        plt.title("Training Progress")
        fig.tight_layout()
        os.makedirs(path, exist_ok=True)
        plot_path = os.path.join(path, "training_plot.png")
        fig.savefig(plot_path, dpi=150)
        plt.close(fig)
        if self.verbose > 0:
            print(f"Training plot saved to {plot_path}")


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description="Train a DQN or PPO agent for station placement.")
    parser.add_argument("--algo", type=str, choices=["dqn", "ppo"], default="dqn",
                        help="RL algorithm to train with (default: dqn)")
    parser.add_argument("--location", type=str, default="DongDa", help="District name (default: DongDa)")
    parser.add_argument("--use_gnn", action="store_true", default=True, help="Use GNN policy (default: True)")
    parser.add_argument("--no_gnn", action="store_true", help="Disable GNN, use MLP policy")
    parser.add_argument("--learning_rate", type=float, default=1e-4, help="Learning rate (default: 1e-4)")
    parser.add_argument("--batch_size", type=int, default=128, help="Batch size (default: 128)")
    parser.add_argument("--buffer_size", type=int, default=20000, help="Replay buffer size (default: 50000)")
    parser.add_argument("--features_dim", type=int, default=256, help="GNN features dimension (default: 256)")
    parser.add_argument("--net_arch", type=int, nargs="+", default=[256, 256], help="Network architecture layers (default: 256 256)")
    parser.add_argument("--exploration_initial_eps", type=float, default=1.0, help="Initial exploration epsilon (default: 1.0)")
    parser.add_argument("--exploration_final_eps", type=float, default=0.05, help="Final exploration epsilon (default: 0.05)")
    parser.add_argument("--exploration_fraction", type=float, default=0.3, help="Exploration fraction (default: 0.3)")
    parser.add_argument("--total_timesteps", type=int, default=200000, help="Total training timesteps (default: 200000)")
    parser.add_argument("--target_update_interval", type=int, default=1000, help="[dqn] Target network update interval (default: 1000)")
    parser.add_argument("--max_grad_norm", type=float, default=1.0, help="Max gradient norm for clipping (default: 1.0)")
    # PPO-only args (ignored when --algo dqn)
    parser.add_argument("--n_steps", type=int, default=2048, help="[ppo] Rollout buffer size per env before each update (default: 2048)")
    parser.add_argument("--n_epochs", type=int, default=10, help="[ppo] Number of epochs per update (default: 10)")
    parser.add_argument("--gae_lambda", type=float, default=0.95, help="[ppo] GAE lambda (default: 0.95)")
    parser.add_argument("--clip_range", type=float, default=0.2, help="[ppo] PPO clip range (default: 0.2)")
    parser.add_argument("--ent_coef", type=float, default=0.0, help="[ppo] Entropy coefficient (default: 0.0)")
    parser.add_argument("--vf_coef", type=float, default=0.5, help="[ppo] Value function coefficient (default: 0.5)")
    parser.add_argument("--seed", type=int, default=1, help="Random seed (default: 1)")
    parser.add_argument("--ns", type=str, default="", help="Namespace of your training run")
    parser.add_argument("--lr_schedule", action="store_true", help="Use linear LR decay (default: constant LR)")
    parser.add_argument("--obs_type", type=str, choices=["mlp", "gnn", "mlp_graph", "attention"], default=None,
                        help="Observation type. Overrides --use_gnn/--no_gnn if set.")
    # AttentionFeaturesExtractor-only args (custom_environment/attention_extractor.py)
    parser.add_argument("--embed_dim", type=int, default=128, help="[attention] per-node embedding width (default: 128)")
    parser.add_argument("--n_heads", type=int, default=4, help="[attention] attention heads, must divide embed_dim (default: 4)")
    parser.add_argument("--n_layers", type=int, default=2, help="[attention] number of self-attention blocks (default: 2)")
    parser.add_argument("--pma_seeds", type=int, default=1, help="[attention] number of PMA seed/query vectors (default: 1)")
    parser.add_argument("--no_pma", action="store_true", help="[attention] disable PMA pooling, use mean-pool ablation baseline instead")
    # Ablation knobs. Main runs pass none of these: the defaults below are the frozen
    # configuration, and every run records the resolved values in its config.json.
    parser.add_argument("--grid_penalty_weight", type=float, default=H.GRID_PENALTY_WEIGHT,
                        help="[ablation] weight on the grid penalty in norm_score; 0 disables it")
    parser.add_argument("--eta", type=float, default=H.DEMAND_ETA,
                        help="[ablation] dynamic-demand scaling factor; 0 gives static demand")
    parser.add_argument("--beta", type=float, default=H.DEMAND_BETA,
                        help="[ablation] dynamic-demand distance decay; 0 removes distance decay")
    parser.add_argument("--grid_mode", type=str, choices=["off", "soft", "hard"], default="hard",
                        help="How the bus-capacity limit is imposed: 'off' (grid-blind), "
                             "'soft' (reward penalty only -- the agent cannot act on it, since "
                             "the node is picked by a grid-blind heuristic), or 'hard' "
                             "(infeasible nodes filtered out before the heuristic runs, so no "
                             "bus can ever be overloaded). Default: hard.")
    parser.add_argument("--no_grid_actions", action="store_true",
                        help="[ablation] keep Discrete(5) in hard mode instead of adding the two "
                             "grid-aware actions, to isolate the effect of the projection alone.")
    parser.add_argument("--grid_headroom_weight", type=float, default=H.GRID_HEADROOM_WEIGHT,
                        help="[ablation] exponent on the headroom term of the grid-aware actions; "
                             "0 makes them plain demand-greedy, larger spreads load harder")
    args = parser.parse_args()

    if args.no_gnn:
        args.use_gnn = False

    # Determine obs_type: explicit --obs_type takes priority
    if args.obs_type:
        obs_type = args.obs_type
    else:
        obs_type = "gnn" if args.use_gnn else "mlp"

    # Set seed for reproducibility
    os.environ['PYTHONHASHSEED'] = '0'
    os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
    torch.manual_seed(args.seed)
    torch.use_deterministic_algorithms(True)
    np.random.seed(args.seed)
    random.seed(args.seed)

    # Instantiate the env
    location = args.location
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "custom_environment", "data")
    graph_file = os.path.join(base_dir, "Graph", location, location + ".graphml")
    node_file = os.path.join(base_dir, "Graph", location, "nodes_extended_" + location + ".txt")
    plan_file = os.path.join(base_dir, "Graph", location, "new_existingplan_" + location + ".pkl")

    # Must precede env construction: reset() already scores the plan and builds the
    # first observation, both of which read these globals.
    H.GRID_PENALTY_WEIGHT = args.grid_penalty_weight
    H.DEMAND_ETA = args.eta
    H.DEMAND_BETA = args.beta
    H.GRID_HEADROOM_WEIGHT = args.grid_headroom_weight
    print(f"[ABLATION] grid_penalty_weight={H.GRID_PENALTY_WEIGHT}, "
          f"eta={H.DEMAND_ETA}, beta={H.DEMAND_BETA}, "
          f"grid_mode={args.grid_mode}, grid_headroom_weight={H.GRID_HEADROOM_WEIGHT}")

    # grid_mode changes BOTH the action-space size (7 vs 5, when grid actions are on)
    # and the observation width, so checkpoints are not interchangeable across modes.
    # It is recorded in config.json below; evaluate_all.py reads it back.
    env = StationPlacement(graph_file, node_file, plan_file, location=location, obs_type=obs_type,
                           grid_mode=args.grid_mode,
                           grid_actions=(not args.no_grid_actions) if args.grid_mode == "hard" else False)
    # PPO runs get their own log_dir (a "/ppo" segment) and modelname prefix so their
    # monitor.csv/config.json/checkpoints never collide with (or get mistaken for) DQN's;
    # DQN keeps its original layout for backward compatibility with evaluate.py /
    # evaluate_all.py / compare_rl.py, which still assume DQN.load().
    algo_dir = "" if args.algo == "dqn" else f"/{args.algo}"
    algo_prefix = "" if args.algo == "dqn" else f"{args.algo}_"
    if args.ns:
        log_dir = f"Results/tmp/{location}/{obs_type}{algo_dir}/{args.ns}"
        modelname = f"best_model_{algo_prefix}{obs_type}_{location}_{args.ns}_"
    else:
        log_dir = f"Results/tmp/{location}/{obs_type}{algo_dir}"
        modelname = f"best_model_{algo_prefix}{obs_type}_{location}_"

    """
    Define and train the agent
    """
    os.makedirs(log_dir, exist_ok=True)

    # Write the config BEFORE training, not after: evaluate_all.py and compare_rl.py
    # read grid_penalty_weight/eta/beta back from it to reproduce this run's reward.
    # Saving it only on completion means an interrupted run leaves checkpoints that
    # cannot be scored correctly, and both scripts would silently fall back to the
    # module defaults.
    config_path = os.path.join(log_dir, "config.json")
    config_data = vars(args).copy()
    config_data.pop("no_gnn", None)  # redundant with use_gnn
    config_data["obs_type"] = obs_type  # save the resolved obs_type
    with open(config_path, "w") as f:
        json.dump(config_data, f, indent=2)
    print(f"Config saved to {config_path}")

    env = Monitor(env, os.path.join(log_dir, "monitor.csv"))

    if obs_type == "gnn":
        from custom_environment.gnn_extractor import GNNFeaturesExtractor
        policy_kwargs = dict(
            features_extractor_class=GNNFeaturesExtractor,
            features_extractor_kwargs=dict(features_dim=args.features_dim),
            net_arch=args.net_arch
        )
        policy_type = "MultiInputPolicy"
    elif obs_type == "attention":
        from custom_environment.attention_extractor import AttentionFeaturesExtractor
        policy_kwargs = dict(
            features_extractor_class=AttentionFeaturesExtractor,
            features_extractor_kwargs=dict(
                embed_dim=args.embed_dim,
                n_heads=args.n_heads,
                n_layers=args.n_layers,
                pma_seeds=args.pma_seeds,
                use_pma=not args.no_pma,
            ),
            net_arch=args.net_arch
        )
        policy_type = "MultiInputPolicy"
    else:
        # Both "mlp" and "mlp_graph" use MlpPolicy (flat observation)
        policy_kwargs = dict(net_arch=args.net_arch)
        policy_type = "MlpPolicy"

    if args.lr_schedule:
        lr = LinearSchedule(start=args.learning_rate, end=args.learning_rate * 0.1, end_fraction=0.7)
    else:
        lr = args.learning_rate

    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    if args.algo == "dqn":
        model = DQN(policy_type, env, verbose=1,
                    batch_size=args.batch_size,
                    buffer_size=args.buffer_size,
                    learning_rate=lr,
                    exploration_initial_eps=args.exploration_initial_eps,
                    exploration_final_eps=args.exploration_final_eps,
                    exploration_fraction=args.exploration_fraction,
                    target_update_interval=args.target_update_interval,
                    max_grad_norm=args.max_grad_norm,
                    policy_kwargs=policy_kwargs,
                    device=device,
                    seed=args.seed)
    else:  # ppo
        model = PPO(policy_type, env, verbose=1,
                    batch_size=args.batch_size,
                    n_steps=args.n_steps,
                    n_epochs=args.n_epochs,
                    learning_rate=lr,
                    gae_lambda=args.gae_lambda,
                    clip_range=args.clip_range,
                    ent_coef=args.ent_coef,
                    vf_coef=args.vf_coef,
                    max_grad_norm=args.max_grad_norm,
                    policy_kwargs=policy_kwargs,
                    device=device,
                    seed=args.seed)
    callback = SaveOnBestTrainingRewardCallback(check_freq=1, my_log_dir=log_dir, my_modelname=modelname)
    model.learn(total_timesteps=args.total_timesteps, log_interval=10 ** 4, callback=callback)

    # Save episode history and plot (config.json was written before training)
    callback.save_history(log_dir)
    callback.plot_history(log_dir)